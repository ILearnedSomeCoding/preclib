param(
    [string]$Emsdk = $env:EMSDK
)

$ErrorActionPreference = 'Stop'
$here = Split-Path -Parent $MyInvocation.MyCommand.Path
$root = Resolve-Path (Join-Path $here '..\..')

$candidates = @()
if($Emsdk){
    if(Test-Path -LiteralPath $Emsdk -PathType Leaf){
        $candidates += $Emsdk
    }else{
        $candidates += (Join-Path $Emsdk 'upstream\emscripten\em++.exe')
        $candidates += (Join-Path $Emsdk 'upstream\emscripten\em++.bat')
        $candidates += (Join-Path $Emsdk 'em++.bat')
    }
}
$candidates += 'C:\emsdk\upstream\emscripten\em++.exe'
$candidates += 'C:\emsdk\upstream\emscripten\em++.bat'
$candidates += (Join-Path $env:USERPROFILE 'emsdk\upstream\emscripten\em++.exe')
$candidates += (Join-Path $env:USERPROFILE 'emsdk\upstream\emscripten\em++.bat')
$candidates += (Join-Path $env:USERPROFILE 'scoop\apps\emscripten\current\em++.bat')
$candidates += 'C:\ProgramData\chocolatey\bin\em++.bat'
$candidates += 'C:\ProgramData\anaconda3\Scripts\em++.bat'
$empp = $candidates | Where-Object { Test-Path -LiteralPath $_ } |
    Select-Object -First 1
if(-not $empp){
    $command = Get-Command 'em++' -ErrorAction SilentlyContinue
    if($command){ $empp = $command.Source }
}
if(-not $empp){
    throw 'em++ was not found. Run emsdk_env.bat or pass -Emsdk C:\path\to\emsdk.'
}

$sources = @(
    (Join-Path $here 'calculator_web.cpp')
)
$sources += Get-ChildItem (Join-Path $root 'cas\src') -Filter '*.cpp' |
    ForEach-Object FullName
$sources += Get-ChildItem (Join-Path $root 'src') -Filter '*.cpp' |
    ForEach-Object FullName

$arguments = @(
    '-O3', '-std=c++17', '-fexceptions',
    '-sMODULARIZE=1', '-sEXPORT_NAME=createCasModule',
    '-sENVIRONMENT=web,worker,node', '-sALLOW_MEMORY_GROWTH=1',
    '-sSINGLE_FILE=1',
    '-sINITIAL_MEMORY=67108864', '-sMAXIMUM_MEMORY=2147483648',
    '-sFILESYSTEM=0', '-sASSERTIONS=0',
    '-sEXPORTED_FUNCTIONS=["_cas_eval","_cas_set_precision","_cas_get_precision","_cas_node_count","_cas_collect","_cas_reset"]',
    '-sEXPORTED_RUNTIME_METHODS=["cwrap"]'
)
$arguments += $sources
$arguments += @('-o', (Join-Path $here 'cas_engine.js'))

& $empp @arguments
if($LASTEXITCODE -ne 0){ throw "Emscripten failed with exit code $LASTEXITCODE" }

# file:// pages cannot let a Worker import another local script. Package the
# engine and worker bootstrap as a Blob source that index.html can load.
$engineSource = [IO.File]::ReadAllText((Join-Path $here 'cas_engine.js'))
$workerSource = [IO.File]::ReadAllText((Join-Path $here 'worker.js'))
$workerSource = [Text.RegularExpressions.Regex]::Replace(
    $workerSource, '^importScripts\([^\r\n]*\);\r?\n', '')
$bundleSource = $engineSource + "`n" + $workerSource
$bundleJson = ConvertTo-Json $bundleSource -Compress
$utf8 = [Text.UTF8Encoding]::new($false)
[IO.File]::WriteAllText((Join-Path $here 'worker_bundle.js'),
    "window.CAS_WORKER_SOURCE=$bundleJson;", $utf8)
Write-Host "Built $here\cas_engine.js and worker_bundle.js (Wasm embedded)"
